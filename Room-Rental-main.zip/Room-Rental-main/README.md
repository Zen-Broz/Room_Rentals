"""
Superuser Credentials:
                        email address = test@gmail.com
                        password = test
                        randomtestmail3@gmail.com
                        supersecret
"""

"""
insert into user_house (house_id, area, floor, district, city, state, cost, bedrooms, kitchen, hall, balcany, desc, AC, booked, img, date, user_email_id)
values
(uuid_generate_v4(), 1234, 3, "Kaski", "Pokhara", "Gandaki Province", 2000000, 4, True, True, True, "Suitable House For Sweet Family", True, False, "/home/kali/Videos/7thsemproject/Rental\ System/projectimages/houses/house1.jpg", "2024-03-04" "test@gmail.com"),   
(uuid_generate_v4() ,1200, 3, "Rupandehi" ,"Butwal", "Lumbini Pradesh", 12000000, 4, True, True, True, ”Best House For You", False, False.” ”),
(uuid_generate_v4() ,1400, 5,  "Kathmandu" , "Kathmandu", "Bagmati Pradesh", 12000000, 4, True, True, True, "Suitable House For Sweet Family", True, False,” ”),
(uuid_generate_v4(),1200, 3,  "Lalitpur" , "Lalitpur", "Bagmati Pradesh", 12000000, 4, True,True, True, ”Best House For You", False,False.” ”),
(uuid_generate_v4() ,1200, 2,  "Bhaktapur" , "Bhaktapur", "Bagmati Pradesh", 12000000, 4, True, True, True, "Suitable House For Sweet Family", False, False,” ”)
(uuid_generate_v4() ,1300, 3,  "Kaski",  "Pokhara", "Gandaki Pradesh", 12000000, 4  ,True, True, True, ”Best House For You", True, False.” ”),
(uuid_generate_v4() ,1200, 4,  "Chitwan",  "Bharatpur", "Bagmati Pradesh", 12000000, 4, True, True, True, ”Your space your rule”, False, False.” ”),
(uuid_generate_v4(),1500, 5,  "Biratnagar",  "Biratnagar", "Province No. 1", 12000000, 4, True, True, True, ”Best House For You", True , False.” ”),
(uuid_generate_v4() ,1200, 3,  "Birgunj", "Birgunj", "Province No. 2", 12000000, 4, True, True, True, "Suitable House For Sweet Family", True, False.” ”),
(uuid_generate_v4() ,1600, 2,  "Rupandehi", "Butwal",  "Lumbini Pradesh", 12000000, 4, True, True, True, ”Best House For You", False, False.” ”),
(uuid_generate_v4() ,1200, 3 , "Hetauda", "Hetauda", "Bagmati Pradesh", 12000000, 4, True, True, True, "Suitable House For Sweet Family", True, False.” ”),
(uuid_generate_v4() ,1300, 5 , "Janakpur",  "Janakpur", "Province No. 2", 12000000, 4, True, True, True, ”Best House For You", False, False.” ”),
(uuid_generate_v4() ,1300, 4 , "Janakpur",  "Janakpur", "Province No. 2", 12000000, 4, True, True, True, "Suitable House For Sweet Family", False,False.” ”),
(uuid_generate_v4() ,1300, 5 , "Itahari", "Itahari", "Province No. 1", 12000000, 4, True, True, True, ”Best House For You", True, False.” ”),
(uuid_generate_v4() ,1500, 2 , "Nepalganj", "Nepalganj", "Sudurpashchim Pradesh", 12000000,4,True, True, True, ”Best House For You", False, False.” ”),
(uuid_generate_v4() ,1300, 5 , "Dang",  "Ghorahi", "Lumbini Pradesh", 12000000, 4, True, True, True, "Suitable House For Sweet Family", True, False.” ”),
(uuid_generate_v4() ,1200, 5 ,"Saptari",  "Rajbiraj", "Province No. 2", 12000000, 4, True, True, True, ”Best House For You", True, False.” ”),
(uuid_generate_v4() ,1300, 5 , "Mahendranagar",  "Mahendranagar", "Sudurpashchim Pradesh" , 12000000,4,True,True, True, ”Best House For You", True,False.” ”)
(uuid_generate_v4() ,1600, 4 , "Bharatpur", "Bharatpur", "Bagmati Pradesh" , 12000000, 4, True, True, True, ”Best House For You", True, False.” ”),
(uuid_generate_v4() ,1400, 5 , "Banepa",  "Banepa", "Bagmati Pradesh" , 12000000, 4, True, True, True, "Suitable House For Sweet Family", True, False.” ”),
(uuid_generate_v4() ,1400, 5 , "Banepa",  "Banepa", "Bagmati Pradesh" , 12000000, 4, True, True, True, ”Stay flexible”, True, False.” ”),
(uuid_generate_v4() ,1300, 3 , "Tansen",  "Tansen", "Lumbini Pradesh" , 12000000, 4, True, True, True, ”Best House For You", True, False.” ”),
(uuid_generate_v4() ,1400, 5 , "Tansen", "Tansen", "Lumbini Pradesh" , 12000000, 4, True, True, True, ”Best House For You", True, False.” ”),
(uuid_generate_v4() ,1500, 4, "Tulsipur",  "Tulsipur", "Lumbini Pradesh" , 12000000, 4, True, True, True, ”Stay satisfied”, False, False.” ”),
(uuid_generate_v4() ,1200, 5 , "Damak",  "Damak", "Province No. 1" , 12000000, 4, True, True, True, ”Best House For You", True, False.” ”);
"# Room-Rental" 
